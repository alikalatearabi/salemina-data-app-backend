// routes/productRoutes.js
const express = require('express');
const router = express.Router();
const { getProductByBarcode, updateProductByBarcode, createProduct, getFirstTenProducts, uploadImage } = require('../controllers/productController');
const { protect } = require('../middleware/auth');
const multer = require('multer');

const storage = multer.memoryStorage();
const upload = multer({ storage });

router.get('/', getFirstTenProducts);
router.get('/:barcode', getProductByBarcode);
router.put('/:barcode', updateProductByBarcode);
router.post('/', createProduct);
router.post('/image', upload.single('image'), uploadImage)

module.exports = router;
