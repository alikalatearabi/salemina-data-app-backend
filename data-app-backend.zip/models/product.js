const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  "Main data status": { type: String, default: '' },
  "Extra data status": { type: String, default: '' },
  importer: { type: String, default: '' },
  monitor: { type: String, default: '' },
  Cluster: { type: String, required: true },  // روغن
  child_cluster: { type: String, required: true },  // روغن آفتابگردان
  product_name: { type: String, required: true },  // روغن آفتابگردان آفتاب 1.5 لیتر
  brand: { type: String, required: true },  // آفتاب
  picture_old: { type: String, default: '' },  // URL for old picture
  picture_new: { type: String, default: '' },  // URL for new picture
  picture_main_info: { type: String, default: '' },
  picture_extra_info: { type: String, default: '' },
  product_description: { type: String, required: true },  // روغن آفتابگردان آفتاب 1.5 لیتر
  barcode: { type: String, required: true, unique: true },  // 6260152300531
  "state of matter": { type: String, default: '0' },
  per: { type: String, default: '0' },  
  calorie: { type: String, default: '0' },  
  sugar: { type: String, default: '0' },
  fat: { type: String, default: '0' },  
  salt: { type: String, default: '0' }, 
  trans_fatty_acids: { type: String, default: '0.14' },  
  per_ext: { type: String, default: '' },
  "Calorie-ext": { type: String, default: '' },
  "Cal-fat": { type: String, default: '' },
  "Total fat": { type: String, default: '' },
  "Saturated fat": { type: String, default: '' },
  "Unsaturated fat": { type: String, default: '' },
  "Trans fat": { type: String, default: '' },
  protein: { type: String, default: '' },
  "Sugar-ext": { type: String, default: '' },
  carbohydrate: { type: String, default: '' },
  fiber: { type: String, default: '' },
  saltExt: { type: String, default: '' },
  sodium: { type: String, default: '' },
  cholesterol: { type: String, default: '' },
}, {
  timestamps: true 
});

const Product = mongoose.model('Product', productSchema, 'product');

module.exports = Product;
